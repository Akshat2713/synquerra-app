class ApiConstants {
  ApiConstants._();

  static const String baseUrl = 'https://api.synquerra.com/';

  // ── Auth ──────────────────────────────────────────
  static const String signIn = 'auth/signin';
  static const String signUp = 'auth/signup';

  // ── Device ────────────────────────────────────────
  static const String deviceList = 'device/list';

  // ── Alerts ────────────────────────────────────────
  static const String alerts = 'alerts-errors/alerts';

  // ── Timeouts ──────────────────────────────────────
  static const int connectTimeoutMs = 30000;
  static const int receiveTimeoutMs = 30000;
  static const int sendTimeoutMs = 30000;

  // ── Retry ─────────────────────────────────────────
  static const int maxRetries = 2;
  static const int retryDelayMs = 800;
}

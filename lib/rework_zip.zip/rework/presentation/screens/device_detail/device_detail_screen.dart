import 'package:flutter/material.dart';

class DeviceDetailScreen extends StatelessWidget {
  final String imei;

  const DeviceDetailScreen({super.key, required this.imei});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Device Details')),
      body: Center(child: Text('IMEI: $imei')),
    );
  }
}

// lib/business/blocs/navigation_bloc/navigation_event.dart
part of 'navigation_bloc.dart';

abstract class NavigationEvent extends Equatable {
  const NavigationEvent();

  @override
  List<Object?> get props => [];
}

class NavigationTabChanged extends NavigationEvent {
  final int index;

  const NavigationTabChanged({required this.index});

  @override
  List<Object?> get props => [index];
}
